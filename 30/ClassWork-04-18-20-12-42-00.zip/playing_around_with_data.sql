SELECT * FROM dbo.Category
SELECT * FROM dbo.Goods

DECLARE @id AS UNIQUEIDENTIFIER
EXECUTE dbo.CreateCategory @categoryName = 'PC Mouse', @guid = @id OUTPUT
SELECT @id
GO

DECLARE @itemId AS INT
EXEC dbo.CreateGoodsItem @categoryName = 'PC Mouse', @goodsItemName = 'Logitech Mouse', @goodsItemId = @itemId OUTPUT
SELECT @itemId
GO

DECLARE @itemId AS INT
EXEC dbo.CreateGoodsItem @categoryName = 'Tablet Mouse', @goodsItemName = 'Logitech Mouse', @goodsItemId = @itemId OUTPUT
SELECT @itemId